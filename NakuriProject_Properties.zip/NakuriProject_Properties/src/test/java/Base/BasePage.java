package Base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePage 
{
	private WebDriver driver;
	protected ExtentReports extent;
    protected ExtentTest test;
    Properties properties;
     public BasePage() {
		// TODO Auto-generated constructor stub
	
          properties = new Properties();
        try {
        	 String propertyFilePath = System.getProperty("user.dir")+"\\src\\main\\resources\\Properties File\\Application.properties";
            FileInputStream fis = new FileInputStream(propertyFilePath);
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     public String getProperty(String key) 
     {
         return properties.getProperty(key);
     }
    
	public WebDriver getdriver()
	{
		return driver;
	}
	public void intinalize(String browser,String url) throws IOException
	{
		switch (browser) 
		{
		case "chrome":
			ChromeOptions option=new ChromeOptions();
		       option.addArguments("--remote-allow-origins=*");
				WebDriverManager.chromedriver().setup();
				driver=new ChromeDriver(option);
				driver.get(url);
			break;
		case "edge":
			 EdgeOptions option1=new EdgeOptions();
		       option1.addArguments("--remote-allow-origins=*");
				WebDriverManager.edgedriver().setup();
				driver=new EdgeDriver(option1);
				driver.get(url);
				break;	
		case "firefox":
			FirefoxOptions option2=new FirefoxOptions();
			option2.addArguments("--remote-allow-origins=*");
			WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver(option2);
			driver.get(url);
		default:
			break;
		}
	}
	 @BeforeSuite
	    public void setUp() {
	        // Set up WebDriver instance
	        // Initialize ExtentReports
	        extent = new ExtentReports();
	        //System.getProperty("user.dir")+"\\src\\main\\resources\\extent.html
	        String reportPath = System.getProperty("user.dir")+"\\src\\main\\resources\\Extend Report\\extent.html";
	        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
	        extent.attachReporter(sparkReporter);
	       // ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("reportPath");
	        //extent.attachReporter(htmlReporter);
	    }
	@BeforeClass
	@Parameters({"browser","url"})
	public void setup(@Optional("edge")String browser,@Optional("https://www.naukri.com/")String url) throws IOException 
	{
		intinalize(browser, url);
		driver.manage().window().maximize();
		
	}
	@AfterClass
	public void tearup()
	{
		//driver.quit();
	}
	@AfterSuite
    public void tearDown() {
        // Quit WebDriver instance
        // Flush ExtentReports
        extent.flush();
    }
	public String takeScreenshot(String screenshotName) {
        // Convert WebDriver object to TakeScreenshot
        TakesScreenshot scrShot = (TakesScreenshot) driver;

        // Call getScreenshotAs method to create image file
        File srcFile = scrShot.getScreenshotAs(OutputType.FILE);

        // Move image file to new destination
  
        String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
       // String destination = "path/to/your/screenshots/folder/" + screenshotName + dateName + ".png";
		String destination=System.getProperty("user.dir")+"\\src\\main\\resources\\Screenshot\\" + screenshotName + dateName + ".png";
        File destFile = new File(destination);

        // Copy file at destination
        try {
            FileUtils.copyFile(srcFile, destFile);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return destination;
    
}

}
