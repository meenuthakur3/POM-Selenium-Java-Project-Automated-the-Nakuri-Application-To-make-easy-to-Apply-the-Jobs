package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.BasePage;

public class JobSearch extends BasePage
{
	WebDriver driver;

	public JobSearch(WebDriver driver)
	{
		super();
		this.driver = driver;
	}
	//Web Element
	By LoginSearchBox=By.xpath("//div[@class='nI-gNb-sb__main']");
	By SearchKeyboard=By.xpath("//input[@placeholder='Enter keyword / designation / companies']");
	By ExperienceDropdown=By.xpath("//input[@id='experienceDD']");
	By SelectYearExperience=By.xpath("//span[normalize-space()='5 years']");
	By Location=By.xpath("//input[@placeholder='Enter location']");
	By SearchBtnClick=By.xpath("//span[normalize-space()='Search']");
	By GetListOfJobCard=By.xpath("//div[@class='cust-job-tuple layout-wrapper lay-2 sjw__tuple ']");
	By ApplyJobBtn=By.xpath("//div[@class='styles_jhc__apply-button-container__5Bqnb']//button[@id='apply-button']");
	public void enterValueSearchPath()
	{
		driver.findElement(LoginSearchBox).click();
		
	}
	
	public void enterSearchDetail()
	{
		driver. manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driver.findElement(SearchKeyboard).sendKeys(getProperty("keywords"));
		driver.findElement(ExperienceDropdown).click();
		driver.findElement(SelectYearExperience).click();
		driver.findElement(Location).sendKeys(getProperty("location"));
		driver.findElement(SearchBtnClick).click();
	}

	public void ClickJob() throws InterruptedException
	{
		System.out.println(driver.getCurrentUrl());
		String originalWindow = driver.getWindowHandle();
		driver.findElement(GetListOfJobCard).click();
		//Loop through until we find a new window handle
		for (String windowHandle : driver.getWindowHandles()) {
		    if(!originalWindow.contentEquals(windowHandle)) {
		        driver.switchTo().window(windowHandle);
		       
		    }
		}
		Thread.sleep(4000);
		driver.findElement(ApplyJobBtn).click();
		System.out.println("Apply button is clicked");
		System.out.println(driver.getCurrentUrl());
		//driver.get(BasePage.getProperty("name"));
		
	}
	
	

}
