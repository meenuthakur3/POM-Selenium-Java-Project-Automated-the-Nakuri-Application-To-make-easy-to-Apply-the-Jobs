package Testing;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.BasePage;
import Pages.JobSearch;
import Pages.LoginPage;
import com.aventstack.extentreports.Status;

public class LoginSwagLab extends BasePage
{
	WebDriver driver;
	private LoginPage lp;
	private JobSearch js;
	String ExpectedHomeUrl="https://www.naukri.com/mnjuser/homepage";
	String ExpectedName="ENETR THE NAME *******";
	String ExpectedRecomendationPageUrl="https://www.naukri.com/mnjuser/recommendedjobs";
	@BeforeClass
	public void setup()
	{
		driver=getdriver();
	}
	//1st Test Method Login
	@Test
	public void verifyLoginNaukri() throws InterruptedException 
	{
		lp=new LoginPage(driver);
		lp.loginNaukriUser();
		test = extent.createTest("UserLogin Sussefully");
        test.log(Status.PASS, "Login successful");
		
	}
	// 2nd Test method to Verify Home page 
	@Test(dependsOnMethods = {"verifyLoginNaukri"})
   public void verifyNakuriHome() throws InterruptedException
   {
		lp=new LoginPage(driver);
		String ActualURL=lp.VeifyNakuriHome();
		test = extent.createTest("UserSuccessfullyLoggedIn-HomePage");
		if (ActualURL.equals(ExpectedHomeUrl))
		{
            test.log(Status.PASS, "Login successful");
        } 
		else 
        {
            test.log(Status.FAIL, "Login failed");
        }
		Assert.assertEquals(ExpectedHomeUrl,ActualURL);
   }
	//3rd Test Case
	@Test (dependsOnMethods = {"verifyNakuriHome"})
	public void getUserName() throws IOException
	{
		lp =new LoginPage(driver);
	String ActualName =lp.VerifyUserName();
	System.out.println("Actual Nmae"+ActualName);
	test = extent.createTest("Verify the User Name in profile");
	if (ActualName.equals(ExpectedName))
	{
        test.log(Status.PASS, "User Name is correct");
    } else 
    {
    	 String screenshotPath = takeScreenshot("testLoginWithValidCredentials");
         test.log(Status.FAIL, "User Name is Not correct")
             .addScreenCaptureFromPath(screenshotPath);
        //test.log(Status.FAIL, "User Name is Not correct");
    }
	Assert.assertEquals(ExpectedName,ActualName);	
	}
	
	//4th Test Case Edit the Profile
	
	@Test (dependsOnMethods = {"getUserName"})
	public void editProfile() throws InterruptedException
	{
		lp=new LoginPage(driver);
		lp.editProfile();
		test=extent.createTest("Profile is edited");
	/*	if(a>b)
		{
			
		}
		else
		{
			
		} */
	}
	
	//5th Click On Recommendation
	@Test (dependsOnMethods = {"editProfile"})
	public void RecomendationPage() throws IOException, InterruptedException 
	{
		lp=new LoginPage(driver);
		lp.getNotification();
		System.out.println("getnotification is clicked");
	
		String ActualRecommendationPage=lp.VerifyRecommendationPage();
		test = extent.createTest("Verify the User In the recommendation Page");
		if (ActualRecommendationPage.equals(ExpectedRecomendationPageUrl))
		{
	        test.log(Status.PASS, "Successulfully landed on The Recommendation Page");
	    } else 
	    {
	    	 String screenshotPath = takeScreenshot("testLoginWithValidCredentials");
	         test.log(Status.FAIL, "User not landed on The Recommendation Page")
	             .addScreenCaptureFromPath(screenshotPath);
	        //test.log(Status.FAIL, "User Name is Not correct");
	    }
		Assert.assertEquals(ExpectedRecomendationPageUrl,ActualRecommendationPage);	
	}
	//6TH TestCase-To get the list of the RecommendationJobs
	@Test (dependsOnMethods = {"RecomendationPage"})
	public void RecommendationList() throws InterruptedException
	{
		lp=new LoginPage(driver);
		lp.RecommendationList();
		
	}
	//7TH test 
	@Test (dependsOnMethods = {"RecommendationList"})
	public void ApplyRecommendationJob() throws InterruptedException
	{
		lp=new LoginPage(driver);
		lp.ApplyRecommendationjobList();
	}
	//8th Test Job Search Page method call
	@Test (dependsOnMethods =  {"ApplyRecommendationJob"})
	public void SearchBoxClick() throws InterruptedException
	{
		js=new JobSearch(driver);
		Thread.sleep(4000);
		lp.enterValueSearchPath();
		System.out.print("value is entred");
	}
	
	//9th Test Enter location year and keyword
	@Test (dependsOnMethods = {"SearchBoxClick"} )
	public void EnterSearchKeywords() throws InterruptedException
	{
		js=new JobSearch(driver);
		js.enterSearchDetail();
		js.ClickJob();
	}
	
	
	
	
}
