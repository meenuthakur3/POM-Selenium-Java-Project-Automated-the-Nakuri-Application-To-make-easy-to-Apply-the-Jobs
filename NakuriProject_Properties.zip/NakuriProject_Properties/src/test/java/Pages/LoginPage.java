package Pages;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.fasterxml.jackson.databind.deser.Deserializers.Base;

import Base.BasePage;

public class LoginPage extends BasePage{
	WebDriver driver;
	Properties pro;


	public LoginPage(Properties pro) {
		super();
		this.pro = pro;
	}


	public LoginPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
     //Web Element
	By LoginBTN = By.xpath("//a[@id='login_Layer']");
	By username = By.xpath("//label[text()='Email ID / Username']/following-sibling::input");
	By password = By.xpath("//label[text()='Password']/following-sibling::input");
	By Login = By.xpath("//button[text()='Login']");
	By profileIcon = By.xpath("//div[@class='nI-gNb-drawer__icon']");
	By getName = By.xpath("//div[@class='nI-gNb-info__heading']");
	By notification=By.xpath("//span[@class='ni-gnb-icn ni-gnb-icn-bell']");
	By recommendation=By.xpath("//div[@title='Recommended jobs']");
	By ViewProfile=By.xpath("//a[normalize-space()='View & Update Profile']");
	By clickEditProfileIcon=By.xpath("//em[@class='icon edit']");
	By ClickeditName=By.xpath("//input[@id='name']");
	By SaveBtn=By.xpath("//button[@id='saveBasicDetailsBtn']");
	By RecommentedJob =By.xpath("//div[contains(@class,'reco-container')]//article");
	By checkboxList =By.xpath("//i[@class='dspIB naukicon naukicon-ot-checkbox']");
	By ApplyJobButton=By.xpath("//button[normalize-space()='Apply 5 Jobs']");
	By CloseSibeBox=By.xpath("//div[@class='crossIcon chatBot chatBot-ic-cross']");
	By LoginSearchBox=By.xpath("//div[@class='nI-gNb-sb__main']");
	
	
	public void enterValueSearchPath()
	{
		driver.findElement(LoginSearchBox).click();
		
	}

	
	public void onclickBTN() 
	{
		driver.findElement(LoginBTN).click();
	}

	public void setusername() 
	{ //String s=getProperty("uname");-----simple way here i am taking input from the properties file
	
		driver.findElement(username).sendKeys(getProperty("uname"));
	}
	public void setpassword() 
	{
		driver.findElement(password).sendKeys(getProperty("password"));
	}
	public void onclick() 
	{
		driver.findElement(Login).click();
	}

	public void clickProfileIcon()
	{
		driver.findElement(profileIcon).click();
	}
	public void ClickNotification()
	{
		driver.findElement(notification).click();
	}
	public void clickRecomendation()
	{
	driver.findElement(recommendation).click();	
	}
	public String VerifyRecommendationPage()
	{
		String RecommendationPage=driver.getCurrentUrl();
		return RecommendationPage;
	}
	
	public void ViewProfileClick()
	{
		driver.findElement(ViewProfile).click();
	}
	public void ClickEditProfileIcon()
	{
		driver.findElement(clickEditProfileIcon).click();
	}
	public void ClickInputName()
	{
	driver.findElement(ClickeditName).click();	
	
	}
	public void clearName()
	{
	driver.findElement(ClickeditName).clear();	
	}
	public void UpdateName()
	{
		driver.findElement(ClickeditName).sendKeys(getProperty("name"));	
	}
	public void clickSaveBtn()
	{
		//driver.findElement(SaveBtn).click();
		WebElement ele=driver.findElement(SaveBtn);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);",ele);
        ele.click();
		
	}
	public void RecommendationJobList() 
	{ 
		List<WebElement> elements=driver.findElements(RecommentedJob);
		System.out.println("Recommendation job "+elements.size());
		System.out.println();
		
	}
	public void ApplyRecommendationjobList()throws InterruptedException
	{
		int i=1;
		List<WebElement> checkbox=driver.findElements(checkboxList);
		System.out.println("CheckBoxList"+checkbox.size());
		  for (WebElement checkbox1 : checkbox)
		  { 
			  if(i<=5)
		  {
			  checkbox1.click();
			  i++;
		  }
	     }
		  driver.findElement(ApplyJobButton).click();
		  Thread.sleep(3000);
		  driver.findElement(CloseSibeBox).click();
		  System.out.println("clicked side box");
	}
	//Login Testing Class Calling Function
	public void loginNaukriUser() throws InterruptedException 
	{
		onclickBTN();
		Thread.sleep(2000);
		setusername();
		setpassword();
		onclick();
	}

	public String VeifyNakuriHome() throws InterruptedException {
		Thread.sleep(5000);
		String ActualUrl = driver.getCurrentUrl();
		return ActualUrl;
	}
	public String VerifyUserName()
	{
		clickProfileIcon();
		String ActualName = driver.findElement(getName).getAttribute("innerHTML");
		return ActualName;
	}
	public void editProfile() throws InterruptedException
	{
		driver. manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Thread.sleep(3000);
		ViewProfileClick();
		Thread.sleep(3000);
		ClickEditProfileIcon();
		ClickInputName();
		Thread.sleep(2000);
		clearName();
		UpdateName();
		Thread.sleep(2000);
		clickSaveBtn();		
	}
	public void getNotification() throws InterruptedException
	{     
	  Thread.sleep(3000);
	  ClickNotification();
	  clickRecomendation();
	}
	
	public void RecommendationList() throws InterruptedException
	{
		Thread.sleep(3000);
		RecommendationJobList();
	}
	
	
	
}
